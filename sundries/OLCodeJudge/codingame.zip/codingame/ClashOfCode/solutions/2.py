import sys,math
h=int(input())
print(h*64)

