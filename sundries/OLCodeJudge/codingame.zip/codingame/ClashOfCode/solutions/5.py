import sys
import math

n = int(input())
print(4, 0)


