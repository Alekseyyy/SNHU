s = input()
print(sum([1 for k in s if k.islower()]))
