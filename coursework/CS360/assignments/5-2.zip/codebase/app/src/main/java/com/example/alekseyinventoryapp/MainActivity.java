package com.example.alekseyinventoryapp;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView displayName;
    Button sayHello;
    EditText insertName;

    public void SayHello(View view){
        String currentName = insertName.getText().toString();
        if (!currentName.equals(null) && !currentName.equals("")) {
            displayName.setText("Hello, " + currentName);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        displayName = findViewById(R.id.textGreeting);
        sayHello = findViewById(R.id.buttonSayHello);
        insertName = findViewById(R.id.nameText);

        sayHello.setOnClickListener(v -> {
            SayHello(v);
        });

        insertName.addTextChangedListener(
                new TextWatcher() {
                    @Override
                    public void afterTextChanged(Editable s) {
                        sayHello.setEnabled(s.toString().trim().length() > 0);
                    }
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }
                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }
                }
        );
    }
}