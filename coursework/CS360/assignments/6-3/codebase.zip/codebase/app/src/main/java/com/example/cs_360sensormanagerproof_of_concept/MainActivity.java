package com.example.cs_360sensormanagerproof_of_concept;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Accelerometer accelerometer;

    /*
      Note that I needed Google's "AI Overview" to remind me
      how to access widgets by their ID's, based off of a St-
      -ackOverflow thread [3].
    */

    private TextView label_xcoord;
    private TextView label_ycoord;
    private TextView label_zcoord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        this.label_xcoord = findViewById(R.id.textView_xcoord);
        this.label_ycoord = findViewById(R.id.textView_ycoord);
        this.label_zcoord = findViewById(R.id.textView_zcoord);

        this.accelerometer = new Accelerometer(this);
        this.accelerometer.register();

        accelerometer.setListener(new Accelerometer.Listener() {
            @Override
            public void onTranslation(float x, float y, float s) {
                /*
                * Note that I had to rely on a Google "AI overview"
                * to remind myself to convert floating point numb-
                * -ers to strings in Java, based on [4].
                */
                String currentX = "X-Coordinate: " + Float.toString(x);
                label_xcoord.setText(currentX);

                String currentY = "Y-Coordinate: " + Float.toString(y);
                label_ycoord.setText(currentY);

                String currentZ = "Z-Coordinate: " + Float.toString(s);
                label_zcoord.setText(currentZ);
            }
        });
    }
}

/*
 References
 1. Kodeco (Jul. 20, 2020). Sensors Tutorial for Android: Getting Started. Retrieved on Oct. 9, 2026 from:
   https://www.kodeco.com/10838302-sensors-tutorial-for-android-getting-started?page=2\#toc-anchor-006
 2. Geeks4Geeks (Jul. 23, 2025). How to Build an Application to Test Motion Sensors in Android? Retrieved on
   Oct. 9, 2026 from: https://www.geeksforgeeks.org/android/how-to-build-an-application-to-test-motion-sensors-in-android/
 3. "eugene_prg" (Jan. 31, 2021). Address elements by ID instead of findViewById. StackOverflow. Retrieved on
   Oct. 9, 2026 from: https://stackoverflow.com/questions/65983738/address-elements-by-id-instead-of-findviewbyid
 4. Gupta, L. (Oct. 4, 2026). Convert Float to String in Java with N Decimal Places. How to do it in Java.
   Retrieved on Oct. 9, 2024 from: https://howtodoinjava.com/java/string/float-to-string-format-decimal-points/
 */
