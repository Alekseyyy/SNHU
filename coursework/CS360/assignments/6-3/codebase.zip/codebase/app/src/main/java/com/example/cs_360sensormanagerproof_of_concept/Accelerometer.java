package com.example.cs_360sensormanagerproof_of_concept;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

// This "Accelerometer" class heavily borrows from "Geeks4Geeks" (2025).
public class Accelerometer {

    private Sensor accSensor;
    private SensorManager saManager;
    private SensorEventListener saListen;
    private Listener lListener;
    public interface Listener {
        void onTranslation(float x, float y, float s);
    }

    public void setListener(Listener lListener) {
        this.lListener = lListener;
    }

    Accelerometer(Context context) {
        this.saManager = (SensorManager)context.getSystemService(
                Context.SENSOR_SERVICE);
        this.accSensor = this.saManager.getDefaultSensor(
                Sensor.TYPE_LINEAR_ACCELERATION);

        this.saListen = new SensorEventListener() {
            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {
                // do nothing for poc-purposes :p
            }

            @Override
            public void onSensorChanged(SensorEvent event) {
                if (lListener != null) {
                    lListener.onTranslation(
                            event.values[0], // x-coordinate
                            event.values[1], // y-coordinate
                            event.values[2]  // z-coordinate
                    ); // set the (x, y, z) coordinates
                }
            }
        }; // Note that much of ``saListen`` was automatically created by Android Studio
    }

    public void register() {
        this.saManager.registerListener(saListen, accSensor,
                SensorManager.SENSOR_DELAY_NORMAL);
    }

    public void unregister() {
        this.saManager.unregisterListener(saListen);
    }
}

/*
 * 1. Geeks4Geeks (Jul. 23, 2025). How to Build an Application to Test Motion Sensors in Android? Retrieved on
Oct. 9, 2026 from: https://www.geeksforgeeks.org/android/how-to-build-an-application-to-test-motion-sensors-in-android/
 */

